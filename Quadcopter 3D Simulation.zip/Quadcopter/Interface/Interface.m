function varargout = Interface(varargin)
% INTERFACE MATLAB code for Interface.fig
%      INTERFACE, by itself, creates a new INTERFACE or raises the existing
%      singleton*.
%
%      H = INTERFACE returns the handle to a new INTERFACE or the handle to
%      the existing singleton*.
%
%      INTERFACE('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in INTERFACE.M with the given input arguments.
%
%      INTERFACE('Property','Value',...) creates a new INTERFACE or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before Interface_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to Interface_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to save (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help Interface

% Last Modified by GUIDE v2.5 19-May-2020 01:42:19

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @Interface_OpeningFcn, ...
                   'gui_OutputFcn',  @Interface_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before Interface is made visible.
function Interface_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to Interface (see VARARGIN)

% Choose default command line output for Interface
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% Initialize image
hold off
plotMWSchematic(handles.MappedTrajectoryAxes);
hold on 
plot(handles.MappedTrajectoryAxes,95,57,'red o')
% Initialization
x=57;
y=95;
z=2;
t=0;
save('trajectory.mat','x','y','z','t')
save('plot.mat','x','y','z')
xt=57;
yt=95;
zt=0;
save('Plottrajectory.mat','xt','yt','zt')
set(handles.North,'String','');
set(handles.East,'String','');
set(handles.Heading,'String','');
set(handles.Waypoint1,'Value',0);
set(handles.Waypoint2,'Value',0);
set(handles.Waypoint3,'Value',0);
set(handles.Waypoint4,'Value',0);
set(handles.Add,'Enable','off');



% UIWAIT makes Interface wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = Interface_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;

% --- Executes on button press in Generate_Trajectory.
function Generate_Trajectory_Callback(hObject, eventdata, handles)
% hObject    handle to Generate_Trajectory (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
C=load('trajectory.mat');
P=load('plot.mat');
plotMWSchematic(handles.MappedTrajectoryAxes);
hold on
plot(handles.MappedTrajectoryAxes,C.y,C.x,'red');
plot(handles.MappedTrajectoryAxes,P.y,P.x,'blue o');
plot(handles.MappedTrajectoryAxes,95,57,'red o')








% --- Executes on button press in Clear.
function Clear_Callback(hObject, eventdata, handles)
% hObject    handle to Clear (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
hold off
plotMWSchematic(handles.MappedTrajectoryAxes);
hold on
plot(handles.MappedTrajectoryAxes,95,57,'red o')

x=57;
y=95;
z=2;
t=0;
save('trajectory.mat','x','y','z','t')
save('plot.mat','x','y','z')
xt=57;
yt=95;
zt=0;
save('Plottrajectory.mat','xt','yt','zt')
set(handles.North,'String','');
set(handles.East,'String','');
set(handles.Heading,'String','');
set(handles.Waypoint1,'Value',0);
set(handles.Waypoint2,'Value',0);
set(handles.Waypoint3,'Value',0);
set(handles.Waypoint4,'Value',0);
set(handles.Add,'Enable','off')



% --- Executes on button press in Waypoint1.
function Waypoint1_Callback(hObject, eventdata, handles)
% hObject    handle to Waypoint1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

plotMWSchematic(handles.MappedTrajectoryAxes);
hold on
plot(handles.MappedTrajectoryAxes,114,88,'blue o')
plot(handles.MappedTrajectoryAxes,95,57,'red o')
x=57;
y=95;
z=2;
t=10;
save('trajectory.mat','x','y','z','t')
save('plot.mat','x','y','z')
set(handles.North,'String','');
set(handles.East,'String','');
set(handles.Heading,'String','');
set(handles.Waypoint2,'Value',0);
set(handles.Waypoint3,'Value',0);
set(handles.Waypoint4,'Value',0);

Xd=[62,69,80,88,88];
Yd=[111,121,118,114,114];
Zd=[2,2,1.46,1.46,0];

X=load('trajectory.mat','x');
x=X.x;
for i=1:length(Xd)
    x(end+1)=Xd(i);
end
save('trajectory.mat','x','-append')
save('plot.mat','x','-append')
Y=load('trajectory.mat','y');
y=Y.y;
for i=1:length(Yd)
    y(end+1)=Yd(i);
end
save('trajectory.mat','y','-append')
save('plot.mat','y','-append')

Z=load('trajectory.mat','z');
z=Z.z;
for i=1:length(Zd)
    z(end+1)=Zd(i);
end
save('trajectory.mat','z','-append')
save('plot.mat','z','-append')
xt=x;
yt=y;
zt=z;
save('Plottrajectory.mat','xt','yt','zt')




% Hint: get(hObject,'Value') returns toggle state of Waypoint1
% --- Executes on button press in Waypoint2.
function Waypoint2_Callback(hObject, eventdata, handles)
% hObject    handle to Waypoint2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
plotMWSchematic(handles.MappedTrajectoryAxes);
hold on
plot(handles.MappedTrajectoryAxes,62,75,'blue o')
plot(handles.MappedTrajectoryAxes,95,57,'red o')
x=57;
y=95;
z=2;
t=10;
save('trajectory.mat','x','y','z','t')
save('plot.mat','x','y','z')
set(handles.North,'String','');
set(handles.East,'String','');
set(handles.Heading,'String','');
set(handles.Waypoint1,'Value',0);
set(handles.Waypoint3,'Value',0);
set(handles.Waypoint4,'Value',0);

Xd=[62,69,92,84,75,75];
Yd=[111,121,115,67,62,62];
Zd=[2,2,2,1.46,1.45,0];

X=load('trajectory.mat','x');
x=X.x;
for i=1:length(Xd)
    x(end+1)=Xd(i);
end
save('trajectory.mat','x','-append')
save('plot.mat','x','-append')

Y=load('trajectory.mat','y');
y=Y.y;
for i=1:length(Yd)
    y(end+1)=Yd(i);
end
save('trajectory.mat','y','-append')
save('plot.mat','y','-append')

Z=load('trajectory.mat','z');
z=Z.z;
for i=1:length(Zd)
    z(end+1)=Zd(i);
end
save('trajectory.mat','z','-append')
save('plot.mat','z','-append')

xt=x;
yt=y;
zt=z;
save('Plottrajectory.mat','xt','yt','zt')

% Hint: get(hObject,'Value') returns toggle state of Waypoint2


% --- Executes on button press in Waypoint3.
function Waypoint3_Callback(hObject, eventdata, handles)
% hObject    handle to Waypoint3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
plotMWSchematic(handles.MappedTrajectoryAxes);
hold on
plot(handles.MappedTrajectoryAxes,37,45,'blue o')
plot(handles.MappedTrajectoryAxes,95,57,'red o')
x=57;
y=95;
z=3;
t=10;
save('trajectory.mat','x','y','z','t')
save('plot.mat','x','y','z')
set(handles.North,'String','');
set(handles.East,'String','');
set(handles.Heading,'String','');
set(handles.Waypoint1,'Value',0);
set(handles.Waypoint2,'Value',0);
set(handles.Waypoint4,'Value',0);

Xd=[37,18,18,17,14,14,25,34,34,45,45];
Yd=[89,92,92,70,42,23,23,22,22,37,37];
Zd=[3,3,3,3,3,3,3,3,1.46,1.46,0];

X=load('trajectory.mat','x');
x=X.x;
for i=1:length(Xd)
    x(end+1)=Xd(i);
end
save('trajectory.mat','x','-append')
save('plot.mat','x','-append')

Y=load('trajectory.mat','y');
y=Y.y;
for i=1:length(Yd)
    y(end+1)=Yd(i);
end
save('trajectory.mat','y','-append')
save('plot.mat','y','-append')

Z=load('trajectory.mat','z');
z=Z.z;
for i=1:length(Zd)
    z(end+1)=Zd(i);
end
save('trajectory.mat','z','-append')
save('plot.mat','z','-append')

xt=x;
yt=y;
zt=z;
save('Plottrajectory.mat','xt','yt','zt')

% Hint: get(hObject,'Value') returns toggle state of Waypoint3


% --- Executes on button press in Waypoint4.
function Waypoint4_Callback(hObject, eventdata, handles)
% hObject    handle to Waypoint4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

plotMWSchematic(handles.MappedTrajectoryAxes);
hold on
plot(handles.MappedTrajectoryAxes,71.8,44,'blue o')
plot(handles.MappedTrajectoryAxes,95,57,'red o')
x=57;
y=95;
z=2;
t=10;
save('trajectory.mat','x','y','z','t')
save('plot.mat','x','y','z')
set(handles.North,'String','');
set(handles.East,'String','');
set(handles.Heading,'String','');
set(handles.Waypoint1,'Value',0);
set(handles.Waypoint2,'Value',0);
set(handles.Waypoint3,'Value',0);



Xd=[51,44,44];
Yd=[85,71.8,71.8];
Zd=[2,2,0];
t=6.5;

C=load('trajectory.mat');
x=C.x;
y=C.y;
z=C.z;
x=[x Xd];
y=[y Yd];
z=[z Zd];

save('plot.mat','x','y','z')
save('trajectory.mat','x','y','z','t')
xt=x;
yt=y;
zt=z;
save('Plottrajectory.mat','xt','yt','zt')




% Hint: get(hObject,'Value') returns toggle state of Waypoint4


function North_Callback(hObject, eventdata, handles)
N=str2double(get(hObject,'String'));
if isnan(N)
    uicontrol(hObject);
    f = errordlg('Input must be a number','Error');
    set(hObject,'String','')
end
if N>102
    uicontrol(hObject);
    f = errordlg('Out of the boundaries of the map','Error');
    set(hObject,'String','')
end
if isnan(N)|isnan(str2double(get(handles.Heading,'String')))|isnan(str2double(get(handles.East,'String')))
    set(handles.Add,'Enable','off')
    
elseif get(handles.Waypoint1,'Value')==1|get(handles.Waypoint2,'Value')==1|get(handles.Waypoint3,'Value')==1|get(handles.Waypoint4,'Value')==1
    set(handles.Add,'Enable','off')
else
    set(handles.Add,'Enable','on')
end

% hObject    handle to North (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% Hints: get(hObject,'String') returns contents of North as text
%        str2double(get(hObject,'String')) returns contents of North as a double



function East_Callback(hObject, eventdata, handles)
% hObject    handle to East (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
E=str2double(get(hObject,'String'));
if isnan(E)
    uicontrol(hObject);
    f = errordlg('Input must be a number','Error');
    set(hObject,'String','')
end
if E>125
    uicontrol(hObject);
    f = errordlg('Out of the boundaries of the map','Error');
    set(hObject,'String','')
end
if (isnan(E)|isnan(str2double(get(handles.North,'String')))|isnan(str2double(get(handles.Heading,'String'))))
    set(handles.Add,'Enable','off')
    
elseif get(handles.Waypoint1,'Value')==1|get(handles.Waypoint2,'Value')==1|get(handles.Waypoint3,'Value')==1|get(handles.Waypoint4,'Value')==1
    set(handles.Add,'Enable','off')
    
else
    set(handles.Add,'Enable','on')
end





% Hints: get(hObject,'String') returns contents of East as text
%        str2double(get(hObject,'String')) returns contents of East as a double



function Heading_Callback(hObject, eventdata, handles)
% hObject    handle to Heading (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
H=str2double(get(hObject,'String'));
if isnan(H)
    uicontrol(hObject);
    f = errordlg('Input must be a number','Error');
    set(hObject,'String','')
end
if H>20
    uicontrol(hObject);
    f = errordlg('Very high altitude','Error');
    set(hObject,'String','')
end
if isnan(H)|isnan(str2double(get(handles.North,'String')))|isnan(str2double(get(handles.East,'String')))
    set(handles.Add,'Enable','off')
    
elseif (get(handles.Waypoint1,'Value')==1|get(handles.Waypoint2,'Value')==1|get(handles.Waypoint3,'Value')==1|get(handles.Waypoint4,'Value')==1)
    set(handles.Add,'Enable','off')
else
    set(handles.Add,'Enable','on')
end




% Hints: get(hObject,'String') returns contents of Heading as text
%        str2double(get(hObject,'String')) returns contents of Heading as a double



% --- Executes on button press in Add.
function Add_Callback(hObject, eventdata, handles)

X=load('plot.mat','x');
N=str2double(get(handles.North,'String'));
x=X.x;
x(end+1)=N;
save('plot.mat','x','-append')

Y=load('plot.mat','y');
E=str2double(get(handles.East,'String'));
y=Y.y;
y(end+1)=E;
save('plot.mat','y','-append')

Z=load('plot.mat','z');
H=str2double(get(handles.Heading,'String'));
z=Z.z;
z(end+1)=H;
save('plot.mat','z','-append')



X=load('trajectory.mat','x');
x=X.x;

Y=load('trajectory.mat','y');
y=Y.y;

syms a b
eqns = [x(end)*a+b == y(end), N*a+b == E];
S = solve(eqns,[a b]);

if x(end)<N
    cx=x(end):1:N;
    cy=S.a*cx+S.b;
end
if x(end)>N
    cx=x(end):-1:N;
    cy=S.a*cx+S.b;
end
if (x(end)==N && y(end)>E)
    cy=y(end):-1:E;
    cx=N.*ones(1,length(cy));
end
if (x(end)==N && y(end)<=E)
    cy=y(end):1:E;
    cx=N.*ones(1,length(cy));
end

Z=load('trajectory.mat','z');
z=Z.z;

[New_A]=Obs(cx,cy,z(end));
x=[x cx];
save('trajectory.mat','x','-append')
y=[y double(cy)];
save('trajectory.mat','y','-append')
z=[z New_A];

z(end+1)=H+0.28;
save('trajectory.mat','z','-append')
t=length(x)/8;
t=ceil(t);
save('trajectory.mat','t','-append')


set(handles.North,'String','');
set(handles.East,'String','');
set(handles.Heading,'String','');


PX=load('plot.mat','x');
PY=load('plot.mat','y');
plotMWSchematic(handles.MappedTrajectoryAxes);
hold on
plot(handles.MappedTrajectoryAxes,PY.y,PX.x,'blue o');
plot(handles.MappedTrajectoryAxes,95,57,'red o')







% hObject    handle to Add (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in Save.
function Save_Callback(hObject, eventdata, handles)
% hObject    handle to Save (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
C=load('trajectory.mat');
xt=C.x;
yt=C.y;
zt=C.z;
x=[];
y=[];
z=[];
t=C.t;
if length(xt)>12
for i=1:floor(length(xt)/10):length(xt)-3
    x=[x xt(i)];
    y=[y yt(i)];
    z=[z zt(i)];
end
for i=2:-1:0
    x(end+1)=xt(length(xt)-i);
    y(end+1)=yt(length(yt)-i);
    z(end+1)=zt(length(zt)-i);
end

a=z(end-2);
b=z(end);
z(end)=z(end-1);
for i=a:-2:b
    x(end+1)=x(end);
    y(end+1)=y(end);
    z(end+1)=i;
end

for i=1:3
    x(end+1)=x(end);
    y(end+1)=y(end);
    z(end+1)=b;
end
else
    x=[x xt];
    y=[y yt];
    z=[z zt];
    a=z(end-1);
    b=z(end);
    z(end)=z(end-1);
    for i=a:-2:b
        x(end+1)=x(end);
        y(end+1)=y(end);
        z(end+1)=i;
    end
    for i=1:3
        x(end+1)=x(end);
        y(end+1)=y(end);
        z(end+1)=b;
	end
end

save('trajectory.mat','x','y','z','t')





