function [New_A]=Obs(N1,E1,z)

C=load('obstacle.mat');

obsN=C.x;
obsE=C.y;
obsA=C.z;
New_A=[];
Altitude=z;

for ii=1:1:length(N1)-1
    
    North=N1(ii);
    East=E1(ii);
    
    North2=N1(ii+1);

    if ((North2-North)>0)
        for i=1:length(obsN)
            if((Altitude-obsA(i))<1)
                if(abs(obsN(i)-North)<2 && abs(obsE(i)-East)<2)
                    Altitude=obsA(i)+2;
                end
            end
        end
    else
        f=length(obsN);
        while(f>0)
            if ((Altitude-obsA(f))<1)
                if(abs(North-obsN(f))<2 && abs(East-obsE(f))<2)
                   Altitude=obsA(f)+2;
                end
            end
            f=f-1;
        end
    end    
    New_A=[New_A Altitude];
end