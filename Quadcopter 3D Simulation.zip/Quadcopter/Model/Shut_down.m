clear all;
clc;

delete('plot.mat')
delete('StarkQuadSimCL7772.slxc')
delete('trajectory.mat')
delete('Plottrajectory.mat')

close('force');