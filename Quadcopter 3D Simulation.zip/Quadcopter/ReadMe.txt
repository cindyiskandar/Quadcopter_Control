To open the Quadcopter Project from the �Quadcopter� Folder:

1. Open MATLAB
2. Double Click on Quadcopter.prj
3. Wait till everything is setup.
4. Enter the Quadcopter trajectory (using the interface)
5. Run the StarkQuad77.m file.


In order for this to work the following Add-ons must be downloaded:

- Aerospace blockset.
- Aerospace toolbox.

To test the control method only please enter the �Control Files Only� folder, you will find the necessary files (without 3D simulation) to test the control only.
